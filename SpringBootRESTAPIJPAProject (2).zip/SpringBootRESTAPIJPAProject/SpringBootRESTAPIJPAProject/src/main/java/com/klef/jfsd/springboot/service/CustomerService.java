package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Customer;

public interface CustomerService 
{
	
	public List<Customer> getAllCustomers();
	
}
